import pandas
from os import system
from word_lib import negative_words

print("Initiating...")
df = pandas.read_csv('dataset_twitter_clean.csv')

print("Dropping empty tweet rows...")
df.dropna(axis=0, how='any', inplace=True)

negative_word_collection = []
label_list = []

print("Analyzing...")
for index, row in df.iterrows():
    tweet = row.get('tweet', "-")
    tweet = tweet.lower()

    # find the negative words in side each tweet
    count_negative_words = 0
    for negative_word in negative_words:
        if tweet.find(negative_word) != -1:
            count_negative_words += 1
            negative_word_collection.append(negative_word)
            
    if count_negative_words > 0:
        label_list.append(0)
    else:
        label_list.append(1)

df['label'] = label_list
df.to_csv("dataset_labeled.csv", index=False)

print(df)
print('Work done!!!')